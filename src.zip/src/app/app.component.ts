import { Component } from '@angular/core';
import { IonApp, IonRouterOutlet } from '@ionic/angular/standalone';
import { ToastComponent } from './components/toast/toast.component';
import { ThemeService } from './pages/theme/theme.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: true,
  imports: [IonApp, IonRouterOutlet,ToastComponent],
})
export class AppComponent { constructor(private themeService: ThemeService) {
    // constructor call zali ki theme automatically load + apply hoto
  }}